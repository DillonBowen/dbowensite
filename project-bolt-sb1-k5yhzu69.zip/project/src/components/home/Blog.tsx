import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, User, ChevronRight } from 'lucide-react';

interface BlogPostProps {
  title: string;
  excerpt: string;
  category: string;
  date: string;
  author: string;
  image: string;
  delay: number;
}

const BlogPost: React.FC<BlogPostProps> = ({ 
  title, 
  excerpt, 
  category, 
  date, 
  author, 
  image, 
  delay 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      viewport={{ once: true }}
      whileHover={{ y: -5 }}
      className="bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 h-full flex flex-col"
    >
      <div className="relative overflow-hidden">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-48 object-cover transition-transform duration-300 transform hover:scale-105"
        />
        <div className="absolute top-4 left-4">
          <span className="px-3 py-1 bg-electric-cyan text-brand-900 text-xs font-semibold rounded-full">
            {category}
          </span>
        </div>
      </div>
      <div className="p-6 flex-grow flex flex-col">
        <h3 className="text-xl font-semibold mb-3 hover:text-electric-cyan transition-colors duration-200">
          <a href="#">{title}</a>
        </h3>
        <p className="text-gray-600 font-lato mb-4 flex-grow">{excerpt}</p>
        <div className="flex items-center text-sm text-gray-500 font-lato mb-4">
          <div className="flex items-center mr-4">
            <Calendar size={14} className="mr-1" />
            <span>{date}</span>
          </div>
          <div className="flex items-center">
            <User size={14} className="mr-1" />
            <span>{author}</span>
          </div>
        </div>
        <motion.a
          href="#"
          whileHover={{ x: 5 }}
          className="flex items-center text-electric-cyan font-medium"
        >
          Read More <ChevronRight size={16} className="ml-1" />
        </motion.a>
      </div>
    </motion.div>
  );
};

const Blog: React.FC = () => {
  const blogPosts = [
    {
      title: "The Future of AI in Content Creation",
      excerpt: "Explore how AI is revolutionizing content creation while maintaining authentic human connections.",
      category: "AI Insights",
      date: "May 15, 2025",
      author: "David Kim",
      image: "https://images.pexels.com/photos/1181271/pexels-photo-1181271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      delay: 0.1
    },
    {
      title: "Ethical Considerations in AI Development",
      excerpt: "Understanding the importance of ethical guidelines and responsible AI implementation.",
      category: "Ethics",
      date: "May 8, 2025",
      author: "Sarah Patel",
      image: "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      delay: 0.2
    },
    {
      title: "Personalization vs. Privacy: Finding Balance",
      excerpt: "How brands can deliver personalized experiences while respecting user privacy and data protection.",
      category: "User Experience",
      date: "April 29, 2025",
      author: "Marcus Johnson",
      image: "https://images.pexels.com/photos/5380642/pexels-photo-5380642.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      delay: 0.3
    }
  ];
  
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-block px-3 py-1 bg-accent-100 text-accent-500 rounded-full text-sm font-semibold mb-4">
            BLOG & INSIGHTS
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Latest Thoughts and Innovations
          </h2>
          <p className="text-gray-600 font-lato max-w-2xl mx-auto leading-relaxed">
            Stay updated with the latest trends, insights, and innovations in AI, 
            digital transformation, and creative technology.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <BlogPost
              key={index}
              title={post.title}
              excerpt={post.excerpt}
              category={post.category}
              date={post.date}
              author={post.author}
              image={post.image}
              delay={post.delay}
            />
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-3 rounded-md border-2 border-electric-cyan text-electric-cyan font-semibold transition-all duration-300 hover:bg-electric-cyan hover:text-white"
          >
            View All Articles
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default Blog;