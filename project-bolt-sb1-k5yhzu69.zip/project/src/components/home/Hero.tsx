import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import ParallaxSection from '../utils/ParallaxSection';

const Hero: React.FC = () => {
  const { scrollYProgress } = useScroll();
  const opacity = useTransform(scrollYProgress, [0, 0.3], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.3], [1, 0.9]);

  const scrollToNextSection = () => {
    const heroHeight = window.innerHeight;
    window.scrollTo({
      top: heroHeight,
      behavior: 'smooth'
    });
  };

  const buttonVariants = {
    hover: {
      scale: 1.05,
      transition: {
        duration: 0.2,
        ease: "easeInOut"
      }
    },
    tap: {
      scale: 0.95
    }
  };

  return (
    <div className="relative min-h-screen flex items-center">
      <div 
        className="absolute inset-0 bg-gradient-to-br from-brand-900 via-brand-800 to-secondary-900 z-0"
        style={{
          backgroundSize: '400% 400%',
        }}
      >
        <div className="absolute inset-0 opacity-10" 
          style={{
            backgroundImage: `radial-gradient(circle at 25px 25px, white 2px, transparent 0)`,
            backgroundSize: '50px 50px'
          }}
        />
      </div>

      <div className="container mx-auto px-4 z-10 pt-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            style={{ opacity, scale }}
            className="text-white space-y-6"
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="inline-block bg-gradient-to-r from-electric-cyan to-neon-magenta bg-clip-text text-transparent font-bold mb-4 py-1 px-4 rounded-full bg-opacity-10 border border-white border-opacity-20"
            >
              INNOVATION • CREATIVITY • PHILANTHROPY
            </motion.div>
            <ParallaxSection offset={-20}>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                Reimagining the Future with{' '}
                <span className="bg-gradient-to-r from-electric-cyan via-coral-pink to-neon-magenta bg-clip-text text-transparent">
                  AI-Powered Innovation
                </span>
              </h1>
            </ParallaxSection>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-lg md:text-xl text-gray-200 font-lato leading-relaxed max-w-lg"
            >
              DK Sevillon blends cutting-edge technology with a human touch to create personalized 
              experiences that inspire, engage, and make a positive impact.
            </motion.p>
            <div className="flex flex-wrap gap-4 pt-2">
              <motion.button
                variants={buttonVariants}
                whileHover="hover"
                whileTap="tap"
                className="px-8 py-3 rounded-md bg-electric-cyan text-brand-900 font-semibold transition-all duration-300 shadow-lg shadow-electric-cyan/20 hover:shadow-electric-cyan/40"
              >
                Discover Our Services
              </motion.button>
              <motion.button
                variants={buttonVariants}
                whileHover="hover"
                whileTap="tap"
                className="px-8 py-3 rounded-md bg-transparent border-2 border-neon-magenta text-white font-semibold transition-all duration-300 hover:bg-neon-magenta/10"
              >
                Learn Our Story
              </motion.button>
            </div>
          </motion.div>

          <motion.div
            style={{ opacity }}
            className="relative hidden lg:block"
          >
            <ParallaxSection offset={30}>
              <div className="relative w-full h-[500px]">
                <div className="absolute w-80 h-80 bg-gradient-to-r from-electric-cyan to-neon-magenta rounded-full blur-3xl opacity-20 animate-pulse-slow"></div>
                
                <motion.div 
                  animate={{ 
                    y: [0, -20, 0],
                    rotate: [0, 5, 0]
                  }}
                  transition={{ 
                    duration: 6,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
                >
                  <div className="relative w-64 h-64">
                    {Array.from({ length: 12 }).map((_, i) => (
                      <motion.div 
                        key={i}
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ delay: i * 0.1 }}
                        className="absolute w-2 h-2 rounded-full bg-electric-cyan"
                        style={{
                          top: `${Math.sin(i / 12 * Math.PI * 2) * 100 + 50}%`,
                          left: `${Math.cos(i / 12 * Math.PI * 2) * 100 + 50}%`,
                          animation: `pulse 3s infinite ${i * 0.3}s ease-in-out`
                        }}
                      >
                        <motion.div 
                          className="absolute w-20 h-0.5 bg-gradient-to-r from-electric-cyan to-transparent"
                          style={{
                            transform: `rotate(${i * 30}deg)`,
                            transformOrigin: 'left center'
                          }}
                        ></motion.div>
                      </motion.div>
                    ))}
                    
                    <motion.div 
                      animate={{ 
                        scale: [1, 1.1, 1],
                        opacity: [0.8, 1, 0.8]
                      }}
                      transition={{ 
                        duration: 3,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                      className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-24 h-24 bg-gradient-to-br from-neon-magenta to-electric-cyan rounded-full blur-sm"
                    ></motion.div>
                  </div>
                </motion.div>
              </div>
            </ParallaxSection>
          </motion.div>
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white cursor-pointer z-10"
        onClick={scrollToNextSection}
      >
        <div className="flex flex-col items-center">
          <span className="text-sm font-light mb-2">Scroll Down</span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
          >
            <ChevronDown size={24} />
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
};

export default Hero;