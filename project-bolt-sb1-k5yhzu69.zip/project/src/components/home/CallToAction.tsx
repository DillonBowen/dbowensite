import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const CallToAction: React.FC = () => {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-brand-500 to-deep-blue">
          {/* Neural network pattern overlay */}
          <div className="absolute inset-0 opacity-10" 
            style={{
              backgroundImage: `radial-gradient(circle at 25px 25px, white 2px, transparent 0)`,
              backgroundSize: '50px 50px'
            }}
          />
          
          <div className="relative z-10 py-16 px-8 md:py-20 md:px-12 text-center md:text-left">
            <div className="md:flex items-center justify-between">
              <div className="md:w-2/3 mb-8 md:mb-0">
                <motion.h2 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  viewport={{ once: true }}
                  className="text-3xl md:text-4xl font-bold text-white mb-4"
                >
                  Ready to Transform Your Digital Experience?
                </motion.h2>
                <motion.p 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                  viewport={{ once: true }}
                  className="text-lg text-gray-200 font-lato max-w-2xl"
                >
                  Let's collaborate to create innovative solutions that drive growth, 
                  enhance user experiences, and make a positive impact. Our team is ready 
                  to bring your vision to life.
                </motion.p>
              </div>
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                viewport={{ once: true }}
              >
                <button className="px-8 py-4 bg-white text-brand-500 rounded-md font-semibold text-lg shadow-lg hover:bg-gray-100 transition-colors duration-300 flex items-center group">
                  Get Started Today
                  <ArrowRight size={20} className="ml-2 transform group-hover:translate-x-1 transition-transform duration-300" />
                </button>
              </motion.div>
            </div>
          </div>
          
          {/* Decorative elements */}
          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            viewport={{ once: true }}
            className="absolute top-0 right-0 w-64 h-64 bg-electric-cyan rounded-full filter blur-3xl opacity-20 -mr-32 -mt-32"
          ></motion.div>
          
          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            viewport={{ once: true }}
            className="absolute bottom-0 left-0 w-64 h-64 bg-neon-magenta rounded-full filter blur-3xl opacity-20 -ml-32 -mb-32"
          ></motion.div>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;