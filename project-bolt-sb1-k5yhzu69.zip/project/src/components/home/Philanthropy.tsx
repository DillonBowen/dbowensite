import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Globe, Leaf, BookOpen } from 'lucide-react';

interface InitiativeProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  delay: number;
}

const Initiative: React.FC<InitiativeProps> = ({ 
  title, 
  description, 
  icon, 
  color, 
  delay 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      viewport={{ once: true }}
      className="bg-white rounded-lg shadow-md overflow-hidden p-6 h-full"
    >
      <div className={`w-12 h-12 rounded-full ${color} flex items-center justify-center mb-4`}>
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-gray-600 font-lato">{description}</p>
    </motion.div>
  );
};

const Philanthropy: React.FC = () => {
  const initiatives = [
    {
      title: "Digital Literacy Programs",
      description: "Empowering communities by providing access to technology education and resources to bridge the digital divide.",
      icon: <BookOpen size={24} className="text-white" />,
      color: "bg-coral-pink",
      delay: 0.1
    },
    {
      title: "Sustainable Technology",
      description: "Developing and promoting environmentally friendly tech solutions to reduce the carbon footprint of digital operations.",
      icon: <Leaf size={24} className="text-white" />,
      color: "bg-electric-cyan",
      delay: 0.2
    },
    {
      title: "AI for Social Good",
      description: "Using AI capabilities to address pressing social challenges in healthcare, education, and humanitarian efforts.",
      icon: <Heart size={24} className="text-white" />,
      color: "bg-neon-magenta",
      delay: 0.3
    },
    {
      title: "Global Collaboration Initiatives",
      description: "Fostering international partnerships that leverage technology for cross-cultural understanding and cooperation.",
      icon: <Globe size={24} className="text-white" />,
      color: "bg-lemon-yellow",
      delay: 0.4
    }
  ];
  
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            viewport={{ once: true }}
          >
            <div className="inline-block px-3 py-1 bg-highlight-100 text-highlight-500 rounded-full text-sm font-semibold mb-4">
              OUR PHILANTHROPY
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Making a <span className="text-coral-pink">Positive Impact</span>{' '}
              Through Technology
            </h2>
            <p className="text-gray-600 font-lato leading-relaxed mb-8">
              At DK Sevillon, we believe in using our expertise and resources to create 
              positive change in the world. Our philanthropy initiatives focus on leveraging 
              technology to address social challenges and improve lives.
            </p>
            
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/6646918/pexels-photo-6646918.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Community outreach program" 
                className="rounded-lg shadow-lg w-full h-auto"
              />
              <motion.div
                initial={{ width: 0 }}
                whileInView={{ width: '50%' }}
                transition={{ duration: 1, ease: "easeInOut" }}
                viewport={{ once: true }}
                className="absolute bottom-0 left-0 h-2 bg-gradient-to-r from-electric-cyan to-coral-pink"
              ></motion.div>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            viewport={{ once: true }}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {initiatives.map((initiative, index) => (
                <Initiative
                  key={index}
                  title={initiative.title}
                  description={initiative.description}
                  icon={initiative.icon}
                  color={initiative.color}
                  delay={initiative.delay}
                />
              ))}
            </div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              viewport={{ once: true }}
              className="mt-8 text-center md:text-left"
            >
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 rounded-md bg-coral-pink text-white font-semibold transition-all duration-300 hover:bg-opacity-90"
              >
                Join Our Initiatives
              </motion.button>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Philanthropy;