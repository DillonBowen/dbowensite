import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';

const About: React.FC = () => {
  return (
    <section className="py-20 bg-white overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            viewport={{ once: true }}
            className="order-2 lg:order-1"
          >
            <div className="inline-block px-3 py-1 bg-secondary-100 text-secondary-500 rounded-full text-sm font-semibold mb-4">
              ABOUT DK SEVILLON
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Blending Technology with{' '}
              <span className="text-electric-cyan">Human Creativity</span>
            </h2>
            <p className="text-gray-600 font-lato leading-relaxed mb-6">
              DK Sevillon was founded on the belief that technology should enhance human potential, 
              not replace it. We specialize in creating AI-powered solutions that retain the human 
              touch, ensuring authenticity and relevance in every interaction.
            </p>
            <p className="text-gray-600 font-lato leading-relaxed mb-8">
              Our multidisciplinary team of technologists, creatives, and strategists work together 
              to deliver innovative solutions that address your unique challenges and goals.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              {[
                "Personalized user experiences",
                "Authentic AI-generated content",
                "Accessible, inclusive design",
                "Continuous innovation",
                "Ethical AI implementation",
                "Human-centered approach"
              ].map((value, index) => (
                <div key={index} className="flex items-start space-x-2">
                  <CheckCircle2 className="text-electric-cyan flex-shrink-0 mt-1" size={20} />
                  <span className="text-gray-700 font-lato">{value}</span>
                </div>
              ))}
            </div>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-3 rounded-md bg-brand-500 text-white font-semibold transition-all duration-300 hover:bg-brand-600"
            >
              Learn More About Us
            </motion.button>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            viewport={{ once: true }}
            className="order-1 lg:order-2"
          >
            <div className="relative">
              {/* Image with geometric overlay */}
              <div className="w-full h-full absolute top-0 left-0 bg-gradient-to-r from-electric-cyan to-neon-magenta opacity-30 rounded-lg"></div>
              
              <img 
                src="https://images.pexels.com/photos/3182834/pexels-photo-3182834.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Team collaboration" 
                className="rounded-lg shadow-xl w-full h-auto z-10 relative"
              />
              
              {/* Geometric decoration */}
              <motion.div 
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ delay: 0.3, duration: 0.5 }}
                viewport={{ once: true }}
                className="absolute -top-4 -right-4 w-20 h-20 bg-lemon-yellow rounded-lg z-0"
              ></motion.div>
              
              <motion.div 
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ delay: 0.5, duration: 0.5 }}
                viewport={{ once: true }}
                className="absolute -bottom-4 -left-4 w-24 h-24 bg-coral-pink rounded-lg z-0"
              ></motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;