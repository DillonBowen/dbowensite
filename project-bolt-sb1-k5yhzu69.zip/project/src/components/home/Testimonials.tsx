import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

interface Testimonial {
  id: number;
  quote: string;
  author: string;
  position: string;
  company: string;
  image: string;
  rating: number;
}

const Testimonials: React.FC = () => {
  const testimonials: Testimonial[] = [
    {
      id: 1,
      quote: "DK Sevillon's AI solutions have transformed our content strategy, allowing us to scale while maintaining our authentic voice. Their team provided exceptional support throughout the implementation.",
      author: "Jessica Chen",
      position: "Marketing Director",
      company: "Global Innovations",
      image: "https://images.pexels.com/photos/3769021/pexels-photo-3769021.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      rating: 5
    },
    {
      id: 2,
      quote: "Working with DK Sevillon on our digital transformation was a game-changer. Their innovative approach and attention to detail helped us achieve our goals ahead of schedule.",
      author: "Michael Rodriguez",
      position: "CTO",
      company: "Nexus Systems",
      image: "https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      rating: 5
    },
    {
      id: 3,
      quote: "The philanthropic initiatives driven by DK Sevillon have made a significant impact in our community. Their commitment to using technology for social good is truly inspiring.",
      author: "Aisha Washington",
      position: "Executive Director",
      company: "Community Foundation",
      image: "https://images.pexels.com/photos/3771129/pexels-photo-3771129.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      rating: 5
    }
  ];
  
  const [activeIndex, setActiveIndex] = useState(0);
  
  const nextTestimonial = () => {
    setActiveIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };
  
  const prevTestimonial = () => {
    setActiveIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };
  
  return (
    <section className="py-20 bg-brand-900 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-40 h-40 rounded-full bg-electric-cyan opacity-5"></div>
        <div className="absolute bottom-20 right-10 w-60 h-60 rounded-full bg-neon-magenta opacity-5"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-lemon-yellow opacity-5"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-block px-3 py-1 bg-white bg-opacity-10 text-electric-cyan rounded-full text-sm font-semibold mb-4">
            TESTIMONIALS
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
            What Our Clients Say
          </h2>
          <p className="text-gray-300 font-lato max-w-2xl mx-auto leading-relaxed">
            We're proud to have helped organizations across various industries achieve their goals 
            through innovative technology solutions and human-centered design.
          </p>
        </motion.div>
        
        <div className="max-w-4xl mx-auto relative">
          <motion.div
            key={testimonials[activeIndex].id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5 }}
            className="bg-white bg-opacity-10 backdrop-blur-sm rounded-xl p-8 md:p-10"
          >
            <div className="flex flex-col items-center text-center">
              <div className="mb-6 flex">
                {[...Array(testimonials[activeIndex].rating)].map((_, i) => (
                  <Star key={i} size={20} className="text-lemon-yellow fill-lemon-yellow" />
                ))}
              </div>
              
              <p className="text-xl md:text-2xl text-white font-lato leading-relaxed mb-8">
                "{testimonials[activeIndex].quote}"
              </p>
              
              <div className="mt-6 flex flex-col items-center">
                <div className="w-16 h-16 rounded-full overflow-hidden mb-4">
                  <img 
                    src={testimonials[activeIndex].image} 
                    alt={testimonials[activeIndex].author} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="text-center">
                  <h4 className="text-lg font-semibold text-electric-cyan">
                    {testimonials[activeIndex].author}
                  </h4>
                  <p className="text-gray-300 font-lato">
                    {testimonials[activeIndex].position}, {testimonials[activeIndex].company}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
          
          {/* Navigation Controls */}
          <div className="flex justify-center mt-8 space-x-4">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={prevTestimonial}
              className="w-10 h-10 rounded-full flex items-center justify-center bg-white bg-opacity-10 text-white hover:bg-electric-cyan transition-colors duration-200"
            >
              <ChevronLeft size={20} />
            </motion.button>
            <div className="flex space-x-2 items-center">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveIndex(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === activeIndex ? 'w-8 bg-electric-cyan' : 'bg-white bg-opacity-30'
                  }`}
                ></button>
              ))}
            </div>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={nextTestimonial}
              className="w-10 h-10 rounded-full flex items-center justify-center bg-white bg-opacity-10 text-white hover:bg-electric-cyan transition-colors duration-200"
            >
              <ChevronRight size={20} />
            </motion.button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;