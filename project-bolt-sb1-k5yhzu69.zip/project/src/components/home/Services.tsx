import React from 'react';
import { motion } from 'framer-motion';
import { 
  Brain, 
  Sparkles, 
  PenTool, 
  LineChart, 
  Users, 
  Code
} from 'lucide-react';

interface ServiceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  bgColor: string;
  delay: number;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ 
  title, 
  description, 
  icon, 
  bgColor, 
  delay 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      viewport={{ once: true, margin: "-50px" }}
      whileHover={{ y: -5 }}
      className="bg-white rounded-lg shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl"
    >
      <div className={`h-2 ${bgColor}`}></div>
      <div className="p-6">
        <div className="mb-4">
          {icon}
        </div>
        <h3 className="text-xl font-semibold mb-3">{title}</h3>
        <p className="text-gray-600 font-lato leading-relaxed">{description}</p>
      </div>
    </motion.div>
  );
};

const Services: React.FC = () => {
  const services = [
    {
      title: "AI Solutions",
      description: "Custom AI solutions that integrate seamlessly into your workflows, enhancing productivity and decision-making.",
      icon: <Brain size={40} className="text-electric-cyan" />,
      bgColor: "bg-electric-cyan",
      delay: 0.1
    },
    {
      title: "Digital Transformation",
      description: "Strategic guidance and implementation to transform your business with cutting-edge digital technologies.",
      icon: <Code size={40} className="text-neon-magenta" />,
      bgColor: "bg-neon-magenta",
      delay: 0.2
    },
    {
      title: "Content Creation",
      description: "AI-powered content generation that maintains your brand's authentic voice while scaling your messaging.",
      icon: <PenTool size={40} className="text-coral-pink" />,
      bgColor: "bg-coral-pink",
      delay: 0.3
    },
    {
      title: "Product Innovation",
      description: "Collaborative product development that pushes boundaries and creates unique, valuable user experiences.",
      icon: <Sparkles size={40} className="text-lemon-yellow" />,
      bgColor: "bg-lemon-yellow",
      delay: 0.4
    },
    {
      title: "Trend Analysis",
      description: "Real-time market trend analysis helping you stay ahead of industry developments and consumer preferences.",
      icon: <LineChart size={40} className="text-deep-blue" />,
      bgColor: "bg-deep-blue",
      delay: 0.5
    },
    {
      title: "Community Building",
      description: "Creating engaged communities around your brand through authentic interactions and shared values.",
      icon: <Users size={40} className="text-secondary-500" />,
      bgColor: "bg-secondary-500",
      delay: 0.6
    }
  ];
  
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-block px-3 py-1 bg-primary-100 text-primary-500 rounded-full text-sm font-semibold mb-4">
            OUR SERVICES
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Innovative Solutions for Modern Challenges
          </h2>
          <p className="text-gray-600 font-lato max-w-2xl mx-auto leading-relaxed">
            We combine human creativity with AI capabilities to deliver solutions 
            that are not just technologically advanced, but also empathetic and tailored 
            to your unique needs.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              title={service.title}
              description={service.description}
              icon={service.icon}
              bgColor={service.bgColor}
              delay={service.delay}
            />
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-3 rounded-md bg-brand-500 text-white font-semibold transition-all duration-300 hover:bg-brand-600"
          >
            Explore All Services
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default Services;