import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Brain, 
  Mail, 
  Phone, 
  MapPin, 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin, 
  ArrowRight 
} from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-900 text-white">
      <div className="container mx-auto px-4 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center mb-6">
              <Brain 
                size={32} 
                className="text-white stroke-white fill-electric-cyan mr-2" 
              />
              <span className="text-xl font-bold">
                DK <span className="text-secondary-500">Sevillon</span>
              </span>
            </div>
            <p className="text-gray-300 font-lato">
              Pioneering AI-powered solutions with a human touch, driving innovation 
              and making a positive impact in the world.
            </p>
            <div className="flex space-x-4 mt-6">
              <a href="#" className="text-gray-300 hover:text-electric-cyan transition-colors duration-200">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-electric-cyan transition-colors duration-200">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-electric-cyan transition-colors duration-200">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-electric-cyan transition-colors duration-200">
                <Linkedin size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-6 text-electric-cyan">Quick Links</h3>
            <ul className="space-y-3 font-lato">
              {['About Us', 'Services', 'Projects', 'Blog', 'Philanthropy', 'Contact'].map((item) => (
                <li key={item}>
                  <Link to={`/${item.toLowerCase().replace(' ', '-')}`} className="text-gray-300 hover:text-electric-cyan transition-colors duration-200 flex items-center">
                    <ArrowRight size={16} className="mr-2" />
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-6 text-electric-cyan">Our Services</h3>
            <ul className="space-y-3 font-lato">
              {[
                'AI Solutions',
                'Digital Transformation',
                'Content Creation',
                'Product Innovation',
                'Trend Analysis',
                'Community Building'
              ].map((item) => (
                <li key={item}>
                  <Link to="/services" className="text-gray-300 hover:text-electric-cyan transition-colors duration-200 flex items-center">
                    <ArrowRight size={16} className="mr-2" />
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold mb-6 text-electric-cyan">Contact Us</h3>
            <ul className="space-y-4 font-lato">
              <li className="flex">
                <MapPin size={20} className="mr-3 text-neon-magenta flex-shrink-0" />
                <span className="text-gray-300">1234 Innovation Way, Tech Valley, CA 94103</span>
              </li>
              <li className="flex">
                <Phone size={20} className="mr-3 text-neon-magenta flex-shrink-0" />
                <a href="tel:+11234567890" className="text-gray-300 hover:text-electric-cyan transition-colors duration-200">
                  +1 (123) 456-7890
                </a>
              </li>
              <li className="flex">
                <Mail size={20} className="mr-3 text-neon-magenta flex-shrink-0" />
                <a href="mailto:info@dksevillon.com" className="text-gray-300 hover:text-electric-cyan transition-colors duration-200">
                  info@dksevillon.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-brand-700 text-center md:flex md:justify-between md:items-center">
          <p className="text-gray-400 font-lato">
            &copy; {new Date().getFullYear()} DK Sevillon. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0">
            <ul className="flex flex-wrap justify-center space-x-4 font-lato text-sm">
              <li>
                <a href="#" className="text-gray-400 hover:text-electric-cyan transition-colors duration-200">Privacy Policy</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-electric-cyan transition-colors duration-200">Terms of Service</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-electric-cyan transition-colors duration-200">Cookie Policy</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;