import React from 'react';
import { motion } from 'framer-motion';
import { 
  Brain, 
  Sparkles, 
  PenTool, 
  LineChart, 
  Users, 
  Code,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';

interface ServiceDetailProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  features: string[];
  image: string;
  reversed?: boolean;
  iconColor: string;
}

const ServiceDetail: React.FC<ServiceDetailProps> = ({ 
  icon, 
  title, 
  description, 
  features, 
  image, 
  reversed = false,
  iconColor
}) => {
  return (
    <div className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${reversed ? 'lg:flex-row-reverse' : ''} mb-20`}>
      <motion.div
        initial={{ opacity: 0, x: reversed ? 50 : -50 }}
        whileInView={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.7 }}
        viewport={{ once: true }}
        className={`order-2 ${reversed ? 'lg:order-1' : 'lg:order-2'}`}
      >
        <div className="relative overflow-hidden rounded-lg shadow-xl">
          <img 
            src={image} 
            alt={title} 
            className="w-full h-auto"
          />
          {/* Decorative accent */}
          <div className={`absolute top-0 left-0 w-full h-2 ${iconColor}`}></div>
        </div>
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, x: reversed ? -50 : 50 }}
        whileInView={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.7 }}
        viewport={{ once: true }}
        className={`order-1 ${reversed ? 'lg:order-2' : 'lg:order-1'}`}
      >
        <div className="flex items-center mb-6">
          <div className={`w-12 h-12 rounded-full ${iconColor} bg-opacity-10 flex items-center justify-center mr-4`}>
            {icon}
          </div>
          <h2 className="text-2xl md:text-3xl font-bold">{title}</h2>
        </div>
        
        <p className="text-gray-600 font-lato mb-6 leading-relaxed">
          {description}
        </p>
        
        <div className="space-y-3 mb-8">
          {features.map((feature, index) => (
            <div key={index} className="flex items-start">
              <CheckCircle2 className="text-green-500 mt-1 mr-3 flex-shrink-0" size={18} />
              <p className="text-gray-700">{feature}</p>
            </div>
          ))}
        </div>
        
        <motion.button
          whileHover={{ x: 5 }}
          className="flex items-center font-semibold text-brand-500 hover:text-electric-cyan transition-colors duration-200"
        >
          Learn More <ArrowRight size={18} className="ml-2" />
        </motion.button>
      </motion.div>
    </div>
  );
};

const Services: React.FC = () => {
  const services = [
    {
      icon: <Brain size={30} className="text-electric-cyan" />,
      title: "AI Solutions",
      description: "Our AI solutions are designed to enhance human capabilities, not replace them. We develop custom AI tools that integrate seamlessly with your existing workflows, providing intelligent insights while maintaining your unique voice and approach.",
      features: [
        "Custom AI model development tailored to your specific needs",
        "Seamless integration with existing systems and workflows",
        "Ethical AI implementation with privacy and security as priorities",
        "Ongoing optimization and training for continuous improvement"
      ],
      image: "https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      iconColor: "bg-electric-cyan"
    },
    {
      icon: <Code size={30} className="text-neon-magenta" />,
      title: "Digital Transformation",
      description: "We guide organizations through complete digital transformations, helping you leverage technology to improve efficiency, enhance customer experiences, and stay ahead of industry changes.",
      features: [
        "Comprehensive digital strategy development",
        "Legacy system modernization and cloud migration",
        "Process automation and optimization",
        "Digital workforce enablement and training"
      ],
      image: "https://images.pexels.com/photos/7688336/pexels-photo-7688336.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      reversed: true,
      iconColor: "bg-neon-magenta"
    },
    {
      icon: <PenTool size={30} className="text-coral-pink" />,
      title: "Content Creation",
      description: "Our AI-powered content solutions help you scale your messaging while maintaining your authentic voice. We combine advanced language models with human creativity to produce content that resonates with your audience.",
      features: [
        "AI-assisted content generation that preserves your brand voice",
        "Multi-format content creation for various platforms",
        "Content strategy development and implementation",
        "Performance analytics and continuous optimization"
      ],
      image: "https://images.pexels.com/photos/6956353/pexels-photo-6956353.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      iconColor: "bg-coral-pink"
    },
    {
      icon: <Sparkles size={30} className="text-lemon-yellow" />,
      title: "Product Innovation",
      description: "We help you reimagine products and services through a human-centered design approach enhanced by AI capabilities. Our product innovation services focus on creating solutions that delight users while achieving business objectives.",
      features: [
        "User research and needs analysis",
        "Concept development and prototyping",
        "AI-enhanced product features and capabilities",
        "User testing and iterative refinement"
      ],
      image: "https://images.pexels.com/photos/3862130/pexels-photo-3862130.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      reversed: true,
      iconColor: "bg-lemon-yellow"
    },
    {
      icon: <LineChart size={30} className="text-deep-blue" />,
      title: "Trend Analysis",
      description: "Stay ahead of market changes with our AI-powered trend analysis services. We help you identify emerging patterns, consumer behaviors, and industry shifts before they become mainstream.",
      features: [
        "Real-time market monitoring and data collection",
        "Predictive analytics for trend identification",
        "Competitive landscape analysis",
        "Strategic recommendations based on trend insights"
      ],
      image: "https://images.pexels.com/photos/7666213/pexels-photo-7666213.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      iconColor: "bg-deep-blue"
    },
    {
      icon: <Users size={30} className="text-secondary-500" />,
      title: "Community Building",
      description: "We help brands create engaged, authentic communities around shared values and interests. Our community building strategies combine technology with human connection to foster meaningful relationships.",
      features: [
        "Community strategy development and implementation",
        "Platform selection and customization",
        "Content and engagement planning",
        "Community management and growth strategies"
      ],
      image: "https://images.pexels.com/photos/3184396/pexels-photo-3184396.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      reversed: true,
      iconColor: "bg-secondary-500"
    }
  ];
  
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative py-24 bg-brand-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20" 
          style={{
            backgroundImage: `radial-gradient(circle at 25px 25px, white 2px, transparent 0)`,
            backgroundSize: '50px 50px'
          }}
        />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="inline-block px-3 py-1 bg-white bg-opacity-10 text-electric-cyan rounded-full text-sm font-semibold mb-4"
            >
              OUR SERVICES
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="text-4xl md:text-5xl font-bold text-white mb-6"
            >
              Innovative Solutions for Modern Challenges
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-lg text-gray-300 font-lato mb-8"
            >
              We combine human creativity with AI capabilities to deliver solutions 
              that are not just technologically advanced, but also empathetic and tailored 
              to your unique needs.
            </motion.p>
          </div>
        </div>
      </section>
      
      {/* Services Overview Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Our Expertise and Capabilities
            </h2>
            <p className="text-gray-600 font-lato max-w-2xl mx-auto leading-relaxed">
              Explore our comprehensive range of services designed to help you navigate 
              the complexities of today's digital landscape and create exceptional experiences.
            </p>
          </motion.div>
          
          {services.map((service, index) => (
            <ServiceDetail
              key={index}
              icon={service.icon}
              title={service.title}
              description={service.description}
              features={service.features}
              image={service.image}
              reversed={service.reversed}
              iconColor={service.iconColor}
            />
          ))}
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-xl shadow-xl overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.7 }}
                viewport={{ once: true }}
                className="p-8 md:p-12"
              >
                <h2 className="text-3xl font-bold mb-6">
                  Ready to Transform Your Digital Experience?
                </h2>
                <p className="text-gray-600 font-lato mb-8 leading-relaxed">
                  Let's discuss how our services can help you achieve your goals. 
                  Contact us today for a free consultation and discover the potential 
                  of AI-powered solutions with a human touch.
                </p>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-3 bg-brand-500 text-white rounded-md font-semibold hover:bg-brand-600 transition-colors duration-300"
                >
                  Schedule a Consultation
                </motion.button>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.7 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-electric-cyan to-neon-magenta p-8 md:p-12 text-white"
              >
                <h3 className="text-2xl font-bold mb-6">Our Process</h3>
                <div className="space-y-6">
                  <div className="flex">
                    <div className="w-10 h-10 rounded-full bg-white bg-opacity-20 flex items-center justify-center mr-4 flex-shrink-0">
                      <span className="font-bold">1</span>
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold mb-2">Discovery</h4>
                      <p className="font-lato text-gray-100">
                        We start by understanding your goals, challenges, and current state to establish a clear path forward.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="w-10 h-10 rounded-full bg-white bg-opacity-20 flex items-center justify-center mr-4 flex-shrink-0">
                      <span className="font-bold">2</span>
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold mb-2">Strategy</h4>
                      <p className="font-lato text-gray-100">
                        Based on our findings, we develop a tailored strategy that aligns with your vision and objectives.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="w-10 h-10 rounded-full bg-white bg-opacity-20 flex items-center justify-center mr-4 flex-shrink-0">
                      <span className="font-bold">3</span>
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold mb-2">Implementation</h4>
                      <p className="font-lato text-gray-100">
                        Our team executes the strategy with precision, keeping you involved throughout the process.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="w-10 h-10 rounded-full bg-white bg-opacity-20 flex items-center justify-center mr-4 flex-shrink-0">
                      <span className="font-bold">4</span>
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold mb-2">Optimization</h4>
                      <p className="font-lato text-gray-100">
                        We continuously refine and improve based on performance data and feedback.
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;