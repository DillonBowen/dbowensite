import React from 'react';
import Hero from '../components/home/Hero';
import Services from '../components/home/Services';
import About from '../components/home/About';
import Blog from '../components/home/Blog';
import Philanthropy from '../components/home/Philanthropy';
import Testimonials from '../components/home/Testimonials';
import Contact from '../components/home/Contact';
import CallToAction from '../components/home/CallToAction';

const Home: React.FC = () => {
  return (
    <>
      <Hero />
      <Services />
      <About />
      <Blog />
      <Philanthropy />
      <Testimonials />
      <Contact />
      <CallToAction />
    </>
  );
};

export default Home;