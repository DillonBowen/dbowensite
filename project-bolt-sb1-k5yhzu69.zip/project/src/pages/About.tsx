import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Sparkles, Users, ChevronRight, Award, CheckCircle2 } from 'lucide-react';

const About: React.FC = () => {
  // Team members data
  const teamMembers = [
    {
      name: "David Kim",
      position: "Founder & CEO",
      image: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      bio: "With over 15 years of experience in technology innovation, David founded DK Sevillon with a vision to create AI solutions that maintain the human touch."
    },
    {
      name: "Sarah Patel",
      position: "Chief Technology Officer",
      image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      bio: "Sarah leads our technology strategy and development, ensuring our solutions are cutting-edge, secure, and aligned with our clients' needs."
    },
    {
      name: "Marcus Johnson",
      position: "Creative Director",
      image: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      bio: "Marcus brings creativity and innovation to every project, balancing aesthetics with functionality to create exceptional user experiences."
    },
    {
      name: "Emma Rodriguez",
      position: "Head of Philanthropy",
      image: "https://images.pexels.com/photos/3796217/pexels-photo-3796217.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      bio: "Emma oversees our philanthropic initiatives, ensuring that our technology is used to create positive social impact in communities worldwide."
    }
  ];
  
  // Company values
  const values = [
    {
      icon: <Brain size={32} className="text-electric-cyan" />,
      title: "Innovation",
      description: "We constantly push boundaries and explore new possibilities in technology and design."
    },
    {
      icon: <Users size={32} className="text-neon-magenta" />,
      title: "Collaboration",
      description: "We believe in the power of diverse perspectives working together toward common goals."
    },
    {
      icon: <CheckCircle2 size={32} className="text-coral-pink" />,
      title: "Integrity",
      description: "We operate with transparency, honesty, and ethical practices in all our endeavors."
    },
    {
      icon: <Sparkles size={32} className="text-lemon-yellow" />,
      title: "Excellence",
      description: "We strive for the highest quality in everything we do, from code to communication."
    }
  ];
  
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative py-24 bg-brand-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20" 
          style={{
            backgroundImage: `radial-gradient(circle at 25px 25px, white 2px, transparent 0)`,
            backgroundSize: '50px 50px'
          }}
        />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="inline-block px-3 py-1 bg-white bg-opacity-10 text-electric-cyan rounded-full text-sm font-semibold mb-4"
            >
              ABOUT DK SEVILLON
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="text-4xl md:text-5xl font-bold text-white mb-6"
            >
              Our Story, Mission, and Values
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-lg text-gray-300 font-lato mb-8"
            >
              Learn about the people, philosophy, and passion behind DK Sevillon and our 
              commitment to creating technology that enhances human potential.
            </motion.p>
          </div>
        </div>
      </section>
      
      {/* Our Story Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7 }}
              viewport={{ once: true }}
            >
              <div className="inline-block px-3 py-1 bg-primary-100 text-primary-500 rounded-full text-sm font-semibold mb-4">
                OUR STORY
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                From Vision to Reality
              </h2>
              <div className="text-gray-600 font-lato space-y-4">
                <p>
                  DK Sevillon was founded in 2020 by David Kim with a clear vision: to create 
                  technology that enhances human capabilities rather than replacing them. Having 
                  witnessed the growing disconnect between technological innovation and human needs, 
                  David assembled a team of like-minded experts dedicated to bridging this gap.
                </p>
                <p>
                  Our journey began with a small team working on AI-powered content solutions that 
                  maintained the authentic voice of brands. As our reputation for creating technology 
                  with a human touch grew, so did our team and our capabilities.
                </p>
                <p>
                  Today, DK Sevillon is at the forefront of creating AI solutions that are not only 
                  technologically advanced but also intuitive, empathetic, and aligned with human values. 
                  We continue to push boundaries while staying true to our founding principle: technology 
                  should serve humanity, not the other way around.
                </p>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="rounded-lg overflow-hidden shadow-xl">
                <img 
                  src="https://images.pexels.com/photos/3182834/pexels-photo-3182834.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="DK Sevillon team" 
                  className="w-full h-auto"
                />
              </div>
              
              {/* Timeline dots */}
              <div className="hidden md:block absolute -left-4 top-1/4 bg-electric-cyan w-8 h-8 rounded-full"></div>
              <div className="hidden md:block absolute -left-4 top-2/4 bg-neon-magenta w-8 h-8 rounded-full"></div>
              <div className="hidden md:block absolute -left-4 top-3/4 bg-coral-pink w-8 h-8 rounded-full"></div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Mission & Vision Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-block px-3 py-1 bg-secondary-100 text-secondary-500 rounded-full text-sm font-semibold mb-4">
              MISSION & VISION
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              What Drives Us Forward
            </h2>
            <p className="text-gray-600 font-lato max-w-2xl mx-auto">
              Our mission and vision guide everything we do, from the projects we take on to the way we implement them.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="bg-white p-8 rounded-lg shadow-md"
            >
              <div className="w-12 h-12 bg-electric-cyan bg-opacity-10 rounded-full flex items-center justify-center mb-6">
                <Award size={24} className="text-electric-cyan" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Our Mission</h3>
              <p className="text-gray-600 font-lato mb-4">
                To create AI-powered solutions that enhance human capabilities, foster connection, 
                and drive positive change in the world, all while maintaining the authenticity and 
                ethical standards that people value.
              </p>
              <p className="text-gray-600 font-lato">
                We are committed to developing technology that serves human needs, respects privacy, 
                and promotes inclusivity across all demographics and communities.
              </p>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
              className="bg-white p-8 rounded-lg shadow-md"
            >
              <div className="w-12 h-12 bg-neon-magenta bg-opacity-10 rounded-full flex items-center justify-center mb-6">
                <Sparkles size={24} className="text-neon-magenta" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Our Vision</h3>
              <p className="text-gray-600 font-lato mb-4">
                To be the global leader in creating AI solutions that maintain the perfect balance 
                between technological advancement and human connection, setting the standard for how 
                technology can enhance rather than diminish human experience.
              </p>
              <p className="text-gray-600 font-lato">
                We envision a world where AI amplifies human creativity, empathy, and problem-solving, 
                enabling people to achieve more while staying true to their values and aspirations.
              </p>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Our Values Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-block px-3 py-1 bg-accent-100 text-accent-500 rounded-full text-sm font-semibold mb-4">
              OUR VALUES
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Principles That Guide Us
            </h2>
            <p className="text-gray-600 font-lato max-w-2xl mx-auto">
              Our core values define who we are and how we approach every project and relationship.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-6 rounded-lg shadow-md text-center"
              >
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  {value.icon}
                </div>
                <h3 className="text-xl font-semibold mb-3">{value.title}</h3>
                <p className="text-gray-600 font-lato">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Our Team Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-block px-3 py-1 bg-highlight-100 text-highlight-500 rounded-full text-sm font-semibold mb-4">
              OUR TEAM
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Meet the Minds Behind DK Sevillon
            </h2>
            <p className="text-gray-600 font-lato max-w-2xl mx-auto">
              Our diverse team brings together expertise in technology, design, strategy, and more to create
              solutions that make a difference.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white rounded-lg shadow-md overflow-hidden"
              >
                <div className="h-64 overflow-hidden">
                  <img 
                    src={member.image} 
                    alt={member.name} 
                    className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-1">{member.name}</h3>
                  <p className="text-electric-cyan font-medium mb-3">{member.position}</p>
                  <p className="text-gray-600 font-lato text-sm mb-4">{member.bio}</p>
                  <a 
                    href="#" 
                    className="inline-flex items-center text-brand-500 font-medium hover:text-electric-cyan transition-colors duration-200"
                  >
                    Connect <ChevronRight size={16} className="ml-1" />
                  </a>
                </div>
              </motion.div>
            ))}
          </div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            viewport={{ once: true }}
            className="text-center mt-12"
          >
            <button className="px-8 py-3 rounded-md border-2 border-brand-500 text-brand-500 font-semibold transition-all duration-300 hover:bg-brand-500 hover:text-white">
              View Full Team
            </button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default About;