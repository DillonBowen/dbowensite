import React from 'react';
import { motion } from 'framer-motion';
import { 
  Heart, 
  Globe, 
  Leaf, 
  BookOpen, 
  Calendar, 
  MapPin,
  Users,
  ArrowRight
} from 'lucide-react';

interface InitiativeProps {
  title: string;
  description: string;
  impact: string;
  icon: React.ReactNode;
  image: string;
  color: string;
  reversed?: boolean;
}

const Initiative: React.FC<InitiativeProps> = ({ 
  title, 
  description, 
  impact,
  icon, 
  image, 
  color,
  reversed = false
}) => {
  return (
    <div className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${reversed ? 'lg:flex-row-reverse' : ''} mb-20`}>
      <motion.div
        initial={{ opacity: 0, x: reversed ? 50 : -50 }}
        whileInView={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.7 }}
        viewport={{ once: true }}
        className={`order-2 ${reversed ? 'lg:order-1' : 'lg:order-2'}`}
      >
        <div className="relative overflow-hidden rounded-lg shadow-xl">
          <img 
            src={image} 
            alt={title} 
            className="w-full h-auto"
          />
          {/* Decorative accent */}
          <div className={`absolute top-0 left-0 w-full h-2 ${color}`}></div>
        </div>
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, x: reversed ? -50 : 50 }}
        whileInView={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.7 }}
        viewport={{ once: true }}
        className={`order-1 ${reversed ? 'lg:order-2' : 'lg:order-1'}`}
      >
        <div className="flex items-center mb-6">
          <div className={`w-12 h-12 rounded-full ${color} flex items-center justify-center mr-4`}>
            {icon}
          </div>
          <h2 className="text-2xl md:text-3xl font-bold">{title}</h2>
        </div>
        
        <p className="text-gray-600 font-lato mb-6 leading-relaxed">
          {description}
        </p>
        
        <div className="bg-gray-50 p-6 rounded-lg mb-6">
          <h3 className="text-lg font-semibold mb-3">Impact</h3>
          <p className="text-gray-700 font-lato">
            {impact}
          </p>
        </div>
        
        <motion.button
          whileHover={{ x: 5 }}
          className="flex items-center font-semibold text-brand-500 hover:text-electric-cyan transition-colors duration-200"
        >
          Learn More <ArrowRight size={18} className="ml-2" />
        </motion.button>
      </motion.div>
    </div>
  );
};

const Philanthropy: React.FC = () => {
  // Philanthropy initiatives
  const initiatives = [
    {
      title: "Digital Literacy Programs",
      description: "Our digital literacy programs aim to bridge the digital divide by providing communities with access to technology education and resources. We work with schools, community centers, and non-profit organizations to develop and implement curriculum that empowers individuals with the digital skills needed for the modern world.",
      impact: "Since launching this initiative, we've reached over 5,000 individuals across 20 communities, providing them with essential digital skills and access to technology resources. We've seen a 75% increase in digital proficiency among program participants.",
      icon: <BookOpen size={24} className="text-white" />,
      image: "https://images.pexels.com/photos/7516363/pexels-photo-7516363.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      color: "bg-coral-pink"
    },
    {
      title: "Sustainable Technology",
      description: "We're committed to developing and promoting environmentally friendly tech solutions that reduce the carbon footprint of digital operations. Our sustainable technology initiative focuses on creating energy-efficient products, implementing green IT practices, and researching innovative ways to make technology more sustainable.",
      impact: "Our sustainable technology initiatives have helped reduce carbon emissions by an estimated 2,500 tons annually. We've also partnered with 15 organizations to implement green IT practices, resulting in a 40% reduction in energy consumption across their digital infrastructure.",
      icon: <Leaf size={24} className="text-white" />,
      image: "https://images.pexels.com/photos/3783471/pexels-photo-3783471.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      color: "bg-electric-cyan",
      reversed: true
    },
    {
      title: "AI for Social Good",
      description: "Our AI for Social Good initiative leverages artificial intelligence capabilities to address pressing social challenges in healthcare, education, and humanitarian efforts. We collaborate with organizations worldwide to develop AI solutions that improve access to essential services and resources for vulnerable populations.",
      impact: "Through our AI for Social Good projects, we've developed solutions that have improved healthcare access for over 10,000 people in underserved regions, enhanced educational outcomes for 7,500 students, and supported disaster response efforts that have benefited more than 25,000 individuals.",
      icon: <Heart size={24} className="text-white" />,
      image: "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      color: "bg-neon-magenta"
    },
    {
      title: "Global Collaboration Initiatives",
      description: "We foster international partnerships that leverage technology for cross-cultural understanding and cooperation. Our global collaboration initiatives bring together diverse perspectives to tackle shared challenges, from climate change to public health crises, using technology as a unifying tool.",
      impact: "Our global collaboration platform has facilitated partnerships across 30 countries, bringing together more than 100 organizations to work on shared challenges. These collaborations have resulted in 12 major technological innovations addressing global issues like clean water access and renewable energy.",
      icon: <Globe size={24} className="text-white" />,
      image: "https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      color: "bg-lemon-yellow",
      reversed: true
    }
  ];
  
  // Upcoming events
  const events = [
    {
      title: "Digital Literacy Workshop",
      date: "June 15, 2025",
      location: "San Francisco, CA",
      description: "A hands-on workshop teaching basic digital skills to community members."
    },
    {
      title: "AI for Good Hackathon",
      date: "July 22-24, 2025",
      location: "Virtual Event",
      description: "A global hackathon focused on developing AI solutions for social challenges."
    },
    {
      title: "Sustainable Tech Conference",
      date: "August 10, 2025",
      location: "Seattle, WA",
      description: "A conference exploring the latest innovations in sustainable technology."
    }
  ];
  
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative py-24 bg-brand-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20" 
          style={{
            backgroundImage: `radial-gradient(circle at 25px 25px, white 2px, transparent 0)`,
            backgroundSize: '50px 50px'
          }}
        />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="inline-block px-3 py-1 bg-white bg-opacity-10 text-electric-cyan rounded-full text-sm font-semibold mb-4"
            >
              OUR PHILANTHROPY
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="text-4xl md:text-5xl font-bold text-white mb-6"
            >
              Making a Positive Impact Through Technology
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-lg text-gray-300 font-lato mb-8"
            >
              At DK Sevillon, we believe in using our expertise and resources to create 
              positive change in the world. Our philanthropy initiatives focus on leveraging 
              technology to address social challenges and improve lives.
            </motion.p>
          </div>
        </div>
      </section>
      
      {/* Philanthropy Introduction */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Our Commitment to Giving Back
              </h2>
              <p className="text-gray-600 font-lato leading-relaxed mb-8">
                We believe that technology has the power to transform lives and communities. 
                That's why we dedicate our resources, expertise, and passion to initiatives 
                that create meaningful social impact. From bridging the digital divide to 
                promoting sustainable technology practices, our philanthropy work is guided 
                by a commitment to making technology accessible, beneficial, and empowering for all.
              </p>
              <div className="flex justify-center space-x-8 mt-12">
                <div className="text-center">
                  <div className="text-4xl font-bold text-electric-cyan mb-2">$2.5M+</div>
                  <p className="text-gray-600 font-lato">Donated to initiatives</p>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-neon-magenta mb-2">50,000+</div>
                  <p className="text-gray-600 font-lato">People impacted</p>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-coral-pink mb-2">20+</div>
                  <p className="text-gray-600 font-lato">Countries reached</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Initiatives Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-block px-3 py-1 bg-highlight-100 text-highlight-500 rounded-full text-sm font-semibold mb-4">
              OUR INITIATIVES
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              How We're Making an Impact
            </h2>
            <p className="text-gray-600 font-lato max-w-2xl mx-auto">
              Our philanthropic efforts are focused on key areas where we believe technology 
              can make the most significant positive impact.
            </p>
          </motion.div>
          
          {initiatives.map((initiative, index) => (
            <Initiative
              key={index}
              title={initiative.title}
              description={initiative.description}
              impact={initiative.impact}
              icon={initiative.icon}
              image={initiative.image}
              color={initiative.color}
              reversed={initiative.reversed}
            />
          ))}
        </div>
      </section>
      
      {/* Get Involved Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <div className="inline-block px-3 py-1 bg-primary-100 text-primary-500 rounded-full text-sm font-semibold mb-4">
                GET INVOLVED
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Join Us in Making a Difference
              </h2>
              <p className="text-gray-600 font-lato leading-relaxed mb-8">
                There are many ways to support our philanthropic initiatives and join our 
                mission to create positive change through technology. Whether you're an 
                individual looking to volunteer, a company interested in partnership, or 
                an organization seeking technological support, we welcome your involvement.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <Users size={24} className="text-electric-cyan mb-4" />
                  <h3 className="text-xl font-semibold mb-2">Volunteer</h3>
                  <p className="text-gray-600 font-lato mb-4">
                    Contribute your time and skills to our initiatives.
                  </p>
                  <a href="#" className="text-electric-cyan font-medium hover:underline">Learn More</a>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <Heart size={24} className="text-neon-magenta mb-4" />
                  <h3 className="text-xl font-semibold mb-2">Donate</h3>
                  <p className="text-gray-600 font-lato mb-4">
                    Support our initiatives with financial contributions.
                  </p>
                  <a href="#" className="text-neon-magenta font-medium hover:underline">Contribute Now</a>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <Globe size={24} className="text-coral-pink mb-4" />
                  <h3 className="text-xl font-semibold mb-2">Partner</h3>
                  <p className="text-gray-600 font-lato mb-4">
                    Collaborate with us on initiatives aligned with your values.
                  </p>
                  <a href="#" className="text-coral-pink font-medium hover:underline">Explore Partnerships</a>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <Leaf size={24} className="text-lemon-yellow mb-4" />
                  <h3 className="text-xl font-semibold mb-2">Spread the Word</h3>
                  <p className="text-gray-600 font-lato mb-4">
                    Help us raise awareness about our initiatives.
                  </p>
                  <a href="#" className="text-lemon-yellow font-medium hover:underline">Share Our Story</a>
                </div>
              </div>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 bg-brand-500 text-white rounded-md font-semibold hover:bg-brand-600 transition-colors duration-300"
              >
                Contact Us to Get Involved
              </motion.button>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
              className="bg-white rounded-lg shadow-xl overflow-hidden"
            >
              <div className="p-8">
                <h3 className="text-2xl font-bold mb-6">Upcoming Events</h3>
                
                <div className="space-y-6">
                  {events.map((event, index) => (
                    <div key={index} className="border-b border-gray-200 pb-6 last:border-b-0 last:pb-0">
                      <h4 className="text-xl font-semibold mb-2">{event.title}</h4>
                      <div className="flex items-start space-x-6 mb-3">
                        <div className="flex items-center text-gray-600">
                          <Calendar size={16} className="mr-2" />
                          <span>{event.date}</span>
                        </div>
                        <div className="flex items-center text-gray-600">
                          <MapPin size={16} className="mr-2" />
                          <span>{event.location}</span>
                        </div>
                      </div>
                      <p className="text-gray-600 font-lato mb-3">
                        {event.description}
                      </p>
                      <a href="#" className="text-electric-cyan font-medium hover:underline">Register Now</a>
                    </div>
                  ))}
                </div>
                
                <div className="mt-8 text-center">
                  <a href="#" className="inline-flex items-center font-semibold text-brand-500 hover:text-electric-cyan transition-colors duration-200">
                    View All Events <ArrowRight size={18} className="ml-2" />
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 bg-brand-900 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Together, We Can Make a Difference
              </h2>
              <p className="text-gray-300 font-lato leading-relaxed mb-8">
                Join us in our mission to create a more inclusive, sustainable, and 
                empowered world through technology. Every contribution, no matter how 
                small, helps us extend our impact and reach more communities in need.
              </p>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 bg-white text-brand-900 rounded-md font-semibold hover:bg-gray-100 transition-colors duration-300"
              >
                Support Our Initiatives
              </motion.button>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Philanthropy;