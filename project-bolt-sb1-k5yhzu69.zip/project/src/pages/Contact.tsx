import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Send, 
  MessageSquare, 
  Clock,
  CheckCircle2
} from 'lucide-react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  
  const [formSubmitted, setFormSubmitted] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log(formData);
    // Show success message
    setFormSubmitted(true);
    // Reset form
    setFormData({
      name: '',
      email: '',
      phone: '',
      subject: '',
      message: ''
    });
    // Hide success message after 5 seconds
    setTimeout(() => {
      setFormSubmitted(false);
    }, 5000);
  };
  
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative py-24 bg-brand-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20" 
          style={{
            backgroundImage: `radial-gradient(circle at 25px 25px, white 2px, transparent 0)`,
            backgroundSize: '50px 50px'
          }}
        />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="inline-block px-3 py-1 bg-white bg-opacity-10 text-electric-cyan rounded-full text-sm font-semibold mb-4"
            >
              CONTACT US
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="text-4xl md:text-5xl font-bold text-white mb-6"
            >
              Let's Start a Conversation
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-lg text-gray-300 font-lato mb-8"
            >
              Have a project in mind or want to learn more about our services? 
              We'd love to hear from you and discuss how we can help bring your ideas to life.
            </motion.p>
          </div>
        </div>
      </section>
      
      {/* Contact Information Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="bg-white rounded-lg shadow-md p-8 text-center hover:shadow-lg transition-shadow duration-300"
            >
              <div className="w-16 h-16 bg-electric-cyan bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Mail size={28} className="text-electric-cyan" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Email Us</h3>
              <p className="text-gray-600 font-lato mb-4">
                For inquiries, feedback, or any questions
              </p>
              <a href="mailto:info@dksevillon.com" className="text-electric-cyan font-medium hover:underline">
                info@dksevillon.com
              </a>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="bg-white rounded-lg shadow-md p-8 text-center hover:shadow-lg transition-shadow duration-300"
            >
              <div className="w-16 h-16 bg-neon-magenta bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Phone size={28} className="text-neon-magenta" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Call Us</h3>
              <p className="text-gray-600 font-lato mb-4">
                Speak directly with our team
              </p>
              <a href="tel:+11234567890" className="text-neon-magenta font-medium hover:underline">
                +1 (123) 456-7890
              </a>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
              className="bg-white rounded-lg shadow-md p-8 text-center hover:shadow-lg transition-shadow duration-300"
            >
              <div className="w-16 h-16 bg-coral-pink bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-6">
                <MapPin size={28} className="text-coral-pink" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Visit Us</h3>
              <p className="text-gray-600 font-lato mb-4">
                Our headquarters location
              </p>
              <address className="text-coral-pink font-medium not-italic">
                1234 Innovation Way<br />
                Tech Valley, CA 94103
              </address>
            </motion.div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7 }}
              viewport={{ once: true }}
              className="bg-white rounded-lg shadow-lg overflow-hidden"
            >
              <div className="p-8">
                <h2 className="text-2xl font-bold mb-6">Send Us a Message</h2>
                
                {formSubmitted && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-green-50 border border-green-200 text-green-800 rounded-md p-4 mb-6 flex items-start"
                  >
                    <CheckCircle2 size={20} className="text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Message sent successfully!</p>
                      <p className="text-sm">Thank you for reaching out. We'll get back to you shortly.</p>
                    </div>
                  </motion.div>
                )}
                
                <form onSubmit={handleSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                        Your Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-electric-cyan"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                        Your Email <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-electric-cyan"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-electric-cyan"
                      />
                    </div>
                    <div>
                      <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                        Subject <span className="text-red-500">*</span>
                      </label>
                      <select
                        id="subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-electric-cyan"
                        required
                      >
                        <option value="">Select a subject</option>
                        <option value="General Inquiry">General Inquiry</option>
                        <option value="Project Collaboration">Project Collaboration</option>
                        <option value="Service Information">Service Information</option>
                        <option value="Philanthropy">Philanthropy</option>
                        <option value="Career Opportunities">Career Opportunities</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                      Your Message <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={5}
                      value={formData.message}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-electric-cyan"
                      required
                    ></textarea>
                  </div>
                  
                  <motion.button
                    type="submit"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-6 py-3 bg-gradient-to-r from-electric-cyan to-neon-magenta text-white font-semibold rounded-md flex items-center justify-center transition-all duration-300"
                  >
                    Send Message
                    <Send size={16} className="ml-2" />
                  </motion.button>
                </form>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex mb-4">
                  <div className="w-12 h-12 rounded-full bg-neon-magenta bg-opacity-10 flex items-center justify-center mr-4">
                    <MessageSquare size={24} className="text-neon-magenta" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-1">Live Chat</h3>
                    <p className="text-gray-600 font-lato">
                      Chat with our support team in real-time for immediate assistance.
                    </p>
                  </div>
                </div>
                <button className="px-4 py-2 mt-2 text-sm bg-neon-magenta text-white rounded-md hover:bg-opacity-90 transition-colors duration-200">
                  Start Chat
                </button>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex mb-4">
                  <div className="w-12 h-12 rounded-full bg-coral-pink bg-opacity-10 flex items-center justify-center mr-4">
                    <Clock size={24} className="text-coral-pink" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-1">Office Hours</h3>
                    <div className="text-gray-600 font-lato">
                      <div className="grid grid-cols-2 gap-2">
                        <div>Monday - Friday:</div>
                        <div>9AM - 6PM PST</div>
                        <div>Saturday:</div>
                        <div>10AM - 4PM PST</div>
                        <div>Sunday:</div>
                        <div>Closed</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold mb-4">Frequently Asked Questions</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-brand-500 mb-1">What services do you offer?</h4>
                    <p className="text-gray-600 font-lato text-sm">
                      We offer a range of services including AI Solutions, Digital Transformation, 
                      Content Creation, Product Innovation, Trend Analysis, and Community Building.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-brand-500 mb-1">How can I request a quote?</h4>
                    <p className="text-gray-600 font-lato text-sm">
                      You can request a quote by filling out our contact form or by calling our office 
                      directly. We'll get back to you within 24-48 hours with more information.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-brand-500 mb-1">Do you work with international clients?</h4>
                    <p className="text-gray-600 font-lato text-sm">
                      Yes, we work with clients globally. Our team is equipped to handle projects across 
                      different time zones and cultural contexts.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Map Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold mb-4">Visit Our Office</h2>
              <p className="text-gray-600 font-lato">
                We'd love to meet you in person at our headquarters
              </p>
            </motion.div>
          </div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="bg-white rounded-lg shadow-lg overflow-hidden"
          >
            {/* This would be replaced with an actual map implementation */}
            <div className="h-96 bg-gray-300 relative">
              <div className="absolute inset-0 flex items-center justify-center">
                <p className="text-gray-700 font-medium">
                  Interactive map would be displayed here
                </p>
              </div>
            </div>
            <div className="p-6">
              <div className="flex items-start">
                <MapPin size={20} className="text-coral-pink mt-1 mr-3 flex-shrink-0" />
                <p className="text-gray-700">
                  1234 Innovation Way, Tech Valley, CA 94103<br />
                  <span className="text-sm text-gray-500">
                    Located in the heart of the Tech Valley district, near Central Park
                  </span>
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Contact;