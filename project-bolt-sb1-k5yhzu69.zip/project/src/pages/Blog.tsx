import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Calendar, 
  User, 
  Clock, 
  Search, 
  Tag, 
  ChevronRight, 
  ChevronLeft,
  MessageCircle
} from 'lucide-react';

const Blog: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('All');

  // Blog posts data
  const blogPosts = [
    {
      id: 1,
      title: "The Future of AI in Content Creation",
      excerpt: "Explore how AI is revolutionizing content creation while maintaining authentic human connections. We examine the latest trends and technologies shaping the industry.",
      category: "AI Insights",
      date: "May 15, 2025",
      author: "David Kim",
      readTime: "8 min read",
      image: "https://images.pexels.com/photos/1181271/pexels-photo-1181271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      comments: 12,
      featured: true
    },
    {
      id: 2,
      title: "Ethical Considerations in AI Development",
      excerpt: "Understanding the importance of ethical guidelines and responsible AI implementation. How can we ensure AI serves humanity's best interests?",
      category: "Ethics",
      date: "May 8, 2025",
      author: "Sarah Patel",
      readTime: "6 min read",
      image: "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      comments: 8,
      featured: false
    },
    {
      id: 3,
      title: "Personalization vs. Privacy: Finding Balance",
      excerpt: "How brands can deliver personalized experiences while respecting user privacy and data protection in an increasingly regulated digital landscape.",
      category: "User Experience",
      date: "April 29, 2025",
      author: "Marcus Johnson",
      readTime: "5 min read",
      image: "https://images.pexels.com/photos/5380642/pexels-photo-5380642.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      comments: 15,
      featured: false
    },
    {
      id: 4,
      title: "The Rise of Conversational Interfaces",
      excerpt: "How voice and chat interfaces are changing the way we interact with technology and what this means for businesses adapting to this shift.",
      category: "AI Insights",
      date: "April 22, 2025",
      author: "Emma Rodriguez",
      readTime: "7 min read",
      image: "https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      comments: 6,
      featured: false
    },
    {
      id: 5,
      title: "Digital Philanthropy: Technology for Social Good",
      excerpt: "How technology companies are leveraging their expertise and resources to address social challenges and make a positive impact globally.",
      category: "Philanthropy",
      date: "April 15, 2025",
      author: "David Kim",
      readTime: "9 min read",
      image: "https://images.pexels.com/photos/6646918/pexels-photo-6646918.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      comments: 10,
      featured: false
    },
    {
      id: 6,
      title: "Building AI Systems That Complement Human Skills",
      excerpt: "Strategies for developing AI solutions that enhance rather than replace human capabilities, creating more effective human-machine collaboration.",
      category: "AI Insights",
      date: "April 8, 2025",
      author: "Sarah Patel",
      readTime: "6 min read",
      image: "https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      comments: 9,
      featured: false
    }
  ];
  
  // Categories derived from blog posts
  const categories = ['All', ...Array.from(new Set(blogPosts.map(post => post.category)))];
  
  // Filter posts based on active category
  const filteredPosts = activeCategory === 'All' 
    ? blogPosts 
    : blogPosts.filter(post => post.category === activeCategory);
  
  // Featured post is the first one marked as featured
  const featuredPost = blogPosts.find(post => post.featured);
  
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative py-24 bg-brand-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20" 
          style={{
            backgroundImage: `radial-gradient(circle at 25px 25px, white 2px, transparent 0)`,
            backgroundSize: '50px 50px'
          }}
        />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="inline-block px-3 py-1 bg-white bg-opacity-10 text-electric-cyan rounded-full text-sm font-semibold mb-4"
            >
              BLOG & INSIGHTS
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="text-4xl md:text-5xl font-bold text-white mb-6"
            >
              Latest Thoughts and Innovations
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-lg text-gray-300 font-lato mb-8"
            >
              Stay updated with the latest trends, insights, and innovations in AI, 
              digital transformation, and creative technology.
            </motion.p>
          </div>
        </div>
      </section>
      
      {/* Featured Post Section */}
      {featuredPost && (
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="inline-block px-3 py-1 bg-accent-100 text-accent-500 rounded-full text-sm font-semibold mb-6">
              FEATURED POST
            </div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
            >
              <div className="overflow-hidden rounded-lg shadow-lg">
                <img 
                  src={featuredPost.image} 
                  alt={featuredPost.title} 
                  className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-500"
                />
              </div>
              
              <div>
                <div className="flex items-center space-x-4 mb-4">
                  <span className="inline-block px-3 py-1 bg-electric-cyan text-white text-xs font-semibold rounded-full">
                    {featuredPost.category}
                  </span>
                  <div className="flex items-center text-sm text-gray-500">
                    <Calendar size={14} className="mr-1" />
                    <span>{featuredPost.date}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock size={14} className="mr-1" />
                    <span>{featuredPost.readTime}</span>
                  </div>
                </div>
                
                <h2 className="text-3xl font-bold mb-4 hover:text-electric-cyan transition-colors duration-200">
                  <a href="#">{featuredPost.title}</a>
                </h2>
                
                <p className="text-gray-600 font-lato mb-6 leading-relaxed">
                  {featuredPost.excerpt}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <User size={18} className="mr-2 text-brand-500" />
                    <span className="font-medium">{featuredPost.author}</span>
                  </div>
                  
                  <div className="flex items-center text-gray-500">
                    <MessageCircle size={18} className="mr-1" />
                    <span>{featuredPost.comments} Comments</span>
                  </div>
                </div>
                
                <motion.a
                  href="#"
                  whileHover={{ x: 5 }}
                  className="inline-flex items-center text-electric-cyan font-medium mt-6"
                >
                  Read Full Article <ChevronRight size={16} className="ml-1" />
                </motion.a>
              </div>
            </motion.div>
          </div>
        </section>
      )}
      
      {/* Blog Posts Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-12">
            <div>
              <h2 className="text-3xl font-bold mb-4">All Articles</h2>
              <p className="text-gray-600 font-lato">Explore our collection of insights and thought leadership</p>
            </div>
            
            <div className="mt-6 md:mt-0">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Search articles..." 
                  className="pl-10 pr-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-electric-cyan w-full md:w-64"
                />
                <Search size={18} className="absolute left-3 top-2.5 text-gray-400" />
              </div>
            </div>
          </div>
          
          {/* Categories */}
          <div className="flex flex-wrap gap-2 mb-10">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                  activeCategory === category
                    ? 'bg-electric-cyan text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
          
          {/* Blog Posts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true }}
                className="bg-white rounded-lg shadow-md overflow-hidden h-full flex flex-col"
              >
                <div className="relative overflow-hidden">
                  <img 
                    src={post.image} 
                    alt={post.title} 
                    className="w-full h-48 object-cover transition-transform duration-300 transform hover:scale-105"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-electric-cyan text-white text-xs font-semibold rounded-full">
                      {post.category}
                    </span>
                  </div>
                </div>
                
                <div className="p-6 flex-grow flex flex-col">
                  <div className="flex items-center text-sm text-gray-500 space-x-4 mb-3">
                    <div className="flex items-center">
                      <Calendar size={14} className="mr-1" />
                      <span>{post.date}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock size={14} className="mr-1" />
                      <span>{post.readTime}</span>
                    </div>
                  </div>
                  
                  <h3 className="text-xl font-semibold mb-3 hover:text-electric-cyan transition-colors duration-200">
                    <a href="#">{post.title}</a>
                  </h3>
                  
                  <p className="text-gray-600 font-lato mb-4 flex-grow">{post.excerpt}</p>
                  
                  <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-100">
                    <div className="flex items-center">
                      <User size={16} className="mr-2 text-brand-500" />
                      <span className="text-sm font-medium">{post.author}</span>
                    </div>
                    
                    <div className="flex items-center text-gray-500 text-sm">
                      <MessageCircle size={16} className="mr-1" />
                      <span>{post.comments}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          {/* Pagination */}
          <div className="flex justify-center items-center mt-12">
            <button className="w-10 h-10 rounded-md flex items-center justify-center border border-gray-300 mr-2 hover:bg-gray-100 transition-colors duration-200">
              <ChevronLeft size={18} />
            </button>
            {[1, 2, 3, 4, 5].map((page) => (
              <button
                key={page}
                className={`w-10 h-10 rounded-md flex items-center justify-center mx-1 ${
                  page === 1
                    ? 'bg-electric-cyan text-white'
                    : 'border border-gray-300 hover:bg-gray-100 transition-colors duration-200'
                }`}
              >
                {page}
              </button>
            ))}
            <button className="w-10 h-10 rounded-md flex items-center justify-center border border-gray-300 ml-2 hover:bg-gray-100 transition-colors duration-200">
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </section>
      
      {/* Newsletter Section */}
      <section className="py-16 bg-brand-900 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <div className="inline-block px-3 py-1 bg-white bg-opacity-10 rounded-full text-sm font-semibold mb-4">
                STAY UPDATED
              </div>
              <h2 className="text-3xl font-bold mb-4">Subscribe to Our Newsletter</h2>
              <p className="text-gray-300 font-lato mb-8">
                Get the latest insights, articles, and updates delivered directly to your inbox.
              </p>
              
              <form className="flex flex-col sm:flex-row gap-4">
                <input 
                  type="email" 
                  placeholder="Your email address" 
                  className="px-4 py-3 rounded-md bg-white bg-opacity-10 border border-white border-opacity-20 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-electric-cyan flex-grow"
                />
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  type="submit"
                  className="px-6 py-3 bg-electric-cyan text-brand-900 font-semibold rounded-md hover:bg-opacity-90 transition-colors duration-200"
                >
                  Subscribe
                </motion.button>
              </form>
              <p className="text-sm text-gray-400 mt-4 font-lato">
                We respect your privacy and will never share your information.
              </p>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Blog;