import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Blog from './pages/Blog';
import Philanthropy from './pages/Philanthropy';
import Contact from './pages/Contact';
import ScrollToTop from './components/utils/ScrollToTop';
import ScrollProgress from './components/utils/ScrollProgress';

function App() {
  return (
    <div className="font-montserrat bg-gray-50 text-gray-900">
      <ScrollToTop />
      <ScrollProgress />
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/philanthropy" element={<Philanthropy />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;